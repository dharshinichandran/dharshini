package shopperz.Controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;

import shopperz.DAO.AddDAO;
import shopperz.DAO.AddProductDAO;
import shopperz.DAO.CustomerDAO; 
import shopperz.Model.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class FirstController {
	
	@Autowired
	CustomerDAO s;
	@Autowired
	AddProductDAO p;
	@Autowired 
	AddDAO ad;
	ModelAndView m;
	
	
	
	
	/*@RequestMapping("/")
    public String gouserprofile() {
    System.out.println("index");
    return "index";
    }*/
	@ModelAttribute("staffobj")
	public Customer getCustomer(){
		return new Customer();
	}
	@ModelAttribute("pobj")
	public AddProduct getProduct(){
		return new AddProduct();
	}
	@ModelAttribute("addressobj")
	public AddModel getAddModel(){
		return new AddModel();
	}
	@RequestMapping("/address")
	public String goaddress() {
	System.out.println("address");
	return "address";
	}
	@RequestMapping("/")
	public String goregistration() {
		System.out.println("register");
		return "register";
	}
	
	@RequestMapping("/login")
	public String gouserprofile(){
		System.out.println("login");
		return "login";
	}
	@RequestMapping("/single")
	public String gosingle() {
	System.out.println("single");
	return "single";
	}
	@RequestMapping("/about")
	public String goabout() {
	System.out.println("about");
	return "about";
	}
	@RequestMapping("/viewallproduct")
	public ModelAndView goviewproducts() {
	System.out.println("viewallproduct");
   ModelAndView view=new ModelAndView("viewallproduct");
	view.addObject("data", ad.viewAllAddModels());	
	return view;
	}
	@RequestMapping("/viewpd/{id}")
	public ModelAndView goviewproduct(@PathVariable("id")int id) {
	System.out.println(id);
	ModelAndView view=new ModelAndView("viewproducts");
	view.addObject("data", ad.viewAddModelById(id));	
	return view;
	}
	
	
	@RequestMapping("/save")
	public ModelAndView addC(@Valid @ModelAttribute("staffobj")Customer x,BindingResult br){
		if(br.hasErrors()){
			m= new ModelAndView("register");
			
			m.addObject("staffobj", x);
			return m;
		}
				
			m = new ModelAndView("login");
			
			 if(x.getpassword().equals(x.getRepassword()))
			 {
				 s.addCustomer(x);
			 }
			 else
			 {
				 m= new ModelAndView("registration");
			     m.addObject("staffobj", x);
				return m; 
			 }		
			return m;
		}

	
	@RequestMapping("/index")
	public String index() {
		System.out.println("index");
		return "index";
	}
	@RequestMapping("/menu")
	public String index1() {
		System.out.println("menu");
		return "Menu";

	}
	@RequestMapping("/adproduct")
	public String products() {
		System.out.println("adproduct");
		return "adproduct";
	}                                                                            
	
	@RequestMapping("/contact")
	public String gocontact() {
	System.out.println("contact");
	return "contact";
	}
	@RequestMapping("/products")
	public String goproducts() {
	System.out.println("products");
	return "products";
	}
	@RequestMapping("/View")
    public ModelAndView ViewUser(){
    	ModelAndView m = new ModelAndView("ViewUser");
    	m.addObject("data", s.viewAllCustomer());
    	return m;
    }
	
	@RequestMapping("/add")
	public String goStore(@ModelAttribute("pobj")AddProduct x1, HttpServletRequest req){
		p.addAddProduct(x1);
		MultipartFile itemImage = x1.getProfilePic();
        String rootDirectory =req.getSession().getServletContext().getRealPath("/");
        File f = new File(rootDirectory + "resources\\images\\");
        if(!f.exists())
        f.mkdirs();
        Path path = Paths.get(rootDirectory +"resources\\images\\"+x1.getPid()+".jpg");

        if (itemImage != null && !itemImage.isEmpty()) {
            try {
            itemImage.transferTo(new File(path.toString()));
            System.out.println("Image Uploaded - "+rootDirectory +"resources\\images\\"+x1.getPid()+".jpg");
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException("item image saving failed.", e);
            }
        }
		return "adproduct";
	}
	
	@RequestMapping("/cancelled")
    public String cancelled() {
    System.out.println("cancelled");
    return "cancelled";
    }


	@RequestMapping("/finish")
    public String finish() {
    System.out.println("finish");
    return "finish";
    }


	@RequestMapping("/")
    public String welcome() {
    System.out.println("welcome");
    return "welcome";
    }


	
	@RequestMapping("/welcome")
    public String welcome1() {
    System.out.println("welcome");
    return "welcome";
    }

}




	
	




   