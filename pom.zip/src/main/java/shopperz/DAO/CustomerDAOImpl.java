package shopperz.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import shopperz.Model.Customer;
@Repository
public class CustomerDAOImpl implements CustomerDAO {
	@Autowired 
	SessionFactory sf;
	
	Session s;
	Transaction t;
	Customer obj;
	


	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		s.save(c);
		t.commit();

	}



	public void delCustomer(String fname) {
		// TODO Auto-generated method stub
		
	}



	public void updCustomer(Customer s) {
		// TODO Auto-generated method stub
		
	}



	public Customer viewCustomerById(String fname) {
		// TODO Auto-generated method stub
		return null;
	}



	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

}
