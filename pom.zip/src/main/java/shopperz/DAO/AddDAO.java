package shopperz.DAO;
import java.util.List;
import shopperz.Model.AddModel;
public interface AddDAO {
	void addAddModel(AddModel s2);
	void delAddModel(int aid);
	void updAddModel(AddModel s2);
	AddModel viewAddModelById(int aid);
	List<AddModel> viewAllAddModels();


}
