package shopperz.DAO;
import java.util.List;

import shopperz.Model.AddProduct;

public interface AddProductDAO {
	
	void addProduct(AddProduct p);
	void delProduct(String pid);
	void updProduct(AddProduct p);
	AddProduct viewProductById(String pid);
	List<AddProduct> viewAllCustomer();
	void addAddProduct(AddProduct x1);
	void viewAllAddProduct();
	

}
