package shopperz.DAO;
import java.util.List;
import shopperz.Model.Customer;

public interface CustomerDAO {
	void addCustomer(Customer c);
    void delCustomer(String fname);
    void updCustomer(Customer s);
    Customer viewCustomerById(String fname);
    List<Customer> viewAllCustomer();

}
