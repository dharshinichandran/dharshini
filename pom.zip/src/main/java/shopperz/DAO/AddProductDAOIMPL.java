package shopperz.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import shopperz.Model.AddProduct;
@Repository
public class AddProductDAOIMPL implements AddProductDAO {

	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;
	
	
	
	

	
	public void updProduct(AddProduct p) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct P = (AddProduct)ss.load(AddProduct.class,p.getPid());
		p.setPname(p.getPname());
		p.setQuantity(p.getQuantity());
		ss.saveOrUpdate(p);
		t.commit();
	}

	

	
	


	public void delProduct(String pid) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct p = (AddProduct)ss.load(AddProduct.class,pid);
		ss.delete(p);
		t.commit();
		
	}


	public AddProduct viewProductById(String pid) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		AddProduct p = (AddProduct)ss.load(AddProduct.class,pid);
		t.commit();
		return p;
		
	}


	public List<AddProduct> viewAllCustomer() {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		List<AddProduct> l = ss.createCriteria(AddProduct.class).list();
		t.commit();
		return l;
		
	}


	public void addAddProduct(AddProduct p) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(p);
		t.commit();
		
	}
	public void addProduct(AddProduct p) {
		// TODO Auto-generated method stub
		
	}







	@Override
	public void viewAllAddProduct() {
		// TODO Auto-generated method stub
		
	}

}

	

	